INSTRUCTIONS:

1. Install dependencies

Backend:
---------
cd server
npm install express mongoose cors socket.io
node index.js

Frontend:
----------
cd client
npm install
npm install socket.io-client
npm run dev

2. Make sure MongoDB is running locally (or update the connection string in server/index.js)

3. Visit http://localhost:5173 to use the real-time editor!
