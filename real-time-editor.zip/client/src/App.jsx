import React, { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:3001');

export default function App() {
  const editorRef = useRef(null);
  const [content, setContent] = useState('');

  useEffect(() => {
    socket.on('load-document', (data) => {
      setContent(data);
    });
    socket.on('receive-changes', (data) => {
      if (editorRef.current && editorRef.current.innerHTML !== data) {
        editorRef.current.innerHTML = data;
      }
    });
    return () => {
      socket.off('load-document');
      socket.off('receive-changes');
    };
  }, []);

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = content;
    }
  }, [content]);

  const handleChange = () => {
    const updated = editorRef.current.innerHTML;
    setContent(updated);
    socket.emit('save-document', updated);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-4">Real-Time Collaborative Editor</h1>
      <div
        ref={editorRef}
        contentEditable
        onInput={handleChange}
        className="bg-white p-4 border rounded shadow min-h-[300px]"
      ></div>
    </div>
  );
}
